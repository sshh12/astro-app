"""A subpackage of third-party data that gets bundled with Skyfield."""
